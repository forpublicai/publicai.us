# MOCSI package snapshot (November 2026)

Planning materials from the Maine Open Compute Services Initiative.
Figures are mid-case estimates (model 0e13319), not quotes or an offer of securities.

Start with GrantPackage/External/ summaries, then the .xlsx models.
DecisionLog.md and OpenQuestions.md are living working records.
Full generated package source: https://github.com/fkittredge/mocsi/tree/main/GrantPackage
